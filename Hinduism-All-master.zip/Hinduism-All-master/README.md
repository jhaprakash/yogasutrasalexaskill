# Hinduism-All
Hinduism texts dataset: Yoga Sutras, Satapatha Brahamana, Tirukkula, Hitopadesha
